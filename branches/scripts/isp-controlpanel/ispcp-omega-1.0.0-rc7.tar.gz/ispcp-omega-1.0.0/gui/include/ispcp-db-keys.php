<?php

$ispcp_db_pass_key = '{KEY}';

$ispcp_db_pass_iv = '{IV}';

?>